#!/usr/bin/python

order_of_noise = 0.1

HOMO_index = 94 - 1 # band index starts from 1 for BerkeleyGW

offdiag_n = 145

import numpy as np
import scipy
import random
from numpy import linalg as LA


inputFile = open('eig.dat','r')

inputFile.readline() #
inputFile.readline() # skip header

sig_vxc = []

E_GW = []
E_GGA = []

for line in inputFile.readlines():

    E_GGA.append(float(line.split()[0]))
    E_GW.append(float(line.split()[1]))

    sigma = E_GW[-1] - E_GGA[-1]

    sig_vxc.append(np.complex(sigma))

H_G0W0 = np.diag(sig_vxc)

#noise_real =                np.random.rand(len(eigenvalues),len(eigenvalues))
#noise_imag = scipy.sqrt(-1)*np.random.rand(len(eigenvalues),len(eigenvalues)) 
#noise = noise_real + noise_imag
#noise *= order_of_noise
#H = H_G0W0 + noise

inputFile = open('offdi.txt', 'r')

counter = 0

for line in inputFile.readlines():
	counter = counter + 1
	
i = 0

inputFile.seek(0)

offdiag = np.zeros((offdiag_n,offdiag_n), dtype=np.complex)

while (i < counter):
	
	line = inputFile.readline().split()
	n = int(line[1])
	m = int(line[2])
	real_sig = float(line[10])
	line = inputFile.readline().split()
	imag_sig = float(line[10])
	inputFile.readline()	# skip -- line
	z = np.complex(real_sig,imag_sig)
        if (n != m): offdiag[n][m] = z # make sure you are only including the offdiags so you don't double count
	i = i + 3
	
H = H_G0W0 + offdiag

# this is now the unsymmeterized matrix 

for n in range(len(sig_vxc)):

    for m in np.arange(n,len(sig_vxc)):

        H[m][n] = H[n][m].conjugate()

# the matrix is now symmetric

outputFile = open('H.matrix.full', 'w')

for i in range(offdiag_n):

    for j in range(offdiag_n):

        if (H[i][j] == 0.): outputFile.write('. ')
        else: outputFile.write('X ')

    outputFile.write('\n')

outputFile.close()

# now we can selectively delete things on the offdiagonal

for n in range(len(sig_vxc)):

    for m in range(len(sig_vxc)):

        if (n != m):

            if ( n != HOMO_index and m != HOMO_index): H[n][m] = 0.

#####
#
# ascii art of matrix
#
#####

outputFile = open('H.matrix.clean', 'w')

for i in range(offdiag_n):

    for j in range(offdiag_n):

        if (H[i][j] == 0.): outputFile.write('. ')
        else: outputFile.write('X ')

    outputFile.write('\n')

outputFile.close()


new_eigenvalues, new_eigenvectors = LA.eig(H)


for i in range(len(new_eigenvalues)):

    if (i == HOMO_index): print str(E_GGA[i] + sig_vxc[i]), str(E_GGA[i] + new_eigenvalues[i]), ' HOMO'
    else:                 print str(E_GGA[i] + sig_vxc[i]), str(E_GGA[i] + new_eigenvalues[i])
